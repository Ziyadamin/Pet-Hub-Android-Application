import 'User.dart';
import 'Pet.dart';


class Notification {
  String content;
  User user;
  Pet pet;
